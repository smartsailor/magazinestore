namespace magazinestore.Services;
using Newtonsoft.Json;
using System.Text;

public class AnswerSubmitter
{
    private readonly HttpClient _httpClient;
    private readonly string _baseUrl;

    public AnswerSubmitter(HttpClient httpClient, string baseUrl)
    {
        _httpClient = httpClient;
        _baseUrl = baseUrl;
    }

    public async Task SubmitAnswer(string token, IEnumerable<string> subscriberIds)
    {
        using (var client = new HttpClient())
        { 
            string serializedSubscriberIds = JsonConvert.SerializeObject(subscriberIds);
            var content = new StringContent(serializedSubscriberIds, Encoding.UTF8, "application/json");
            var response = await client.PostAsync($"{_baseUrl}/api/answer/{token}", content);
            
            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadAsStringAsync();
            }
            else
            {
                var errorMessage = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Error: {response.StatusCode} - {errorMessage}");
            }
        }
    }
}