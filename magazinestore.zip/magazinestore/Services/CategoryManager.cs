using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Net.Http.Headers;
using magazinestore.Models;
using System.Text;

namespace magazinestore.Services;

public class CategoryManager
{
    private readonly HttpClient _httpClient;
    private readonly string _baseUrl;

    public CategoryManager(HttpClient httpClient, string baseUrl)
    {
        _httpClient = httpClient;
        _baseUrl = baseUrl;
    }

    public async Task<List<string>> GetCategoryIds(string token)
    {
        _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var response = await _httpClient.GetAsync($"{_baseUrl}/api/categories/{token}");
        response.EnsureSuccessStatusCode();
        var categories = await response.Content.ReadAsStringAsync();
        var catresponse = JsonConvert.DeserializeObject<JsonResponse>(categories);
        return catresponse.Data;
    }
}