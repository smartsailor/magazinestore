using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using magazinestore.Models;

namespace magazinestore.Services;

public class TokenManager
{
    private readonly HttpClient _httpClient;
    private readonly string _baseUrl;

    public TokenManager(HttpClient httpClient, string baseUrl)
    {
        _httpClient = httpClient;
        _baseUrl = baseUrl;
    }

    public async Task<string> GetToken()
    {
        var response = await _httpClient.GetAsync($"{_baseUrl}/api/token");
        response.EnsureSuccessStatusCode();
        var tokenResponse = await response.Content.ReadAsStringAsync();
        JsonStringToken tokenObject = JsonConvert.DeserializeObject<JsonStringToken>(tokenResponse);
        var token = tokenObject?.Token;
        return token;
    }
}