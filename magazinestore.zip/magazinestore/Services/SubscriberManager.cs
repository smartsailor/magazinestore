using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;

namespace magazinestore.Services;

public class SubscriberManager
{
    private readonly HttpClient _httpClient;
    private readonly string _baseUrl;

    public SubscriberManager(HttpClient httpClient, string baseUrl)
    {
        _httpClient = httpClient;
        _baseUrl = baseUrl;
    }

    public async Task<List<string>> GetSubscriberIdsWithMagazinesInAllCategories(string token, IEnumerable<string> categoryIds)
    {
        var subscriberIds = new List<string>();
        var subscribersResponse = await _httpClient.GetAsync($"{_baseUrl}/api/subscribers/{token}");
        subscribersResponse.EnsureSuccessStatusCode();
        var subscribersJson = await subscribersResponse.Content.ReadAsStringAsync();
        JObject jsonObject = JObject.Parse(subscribersJson);
        JArray subscribersArray = (JArray)jsonObject["data"];

        foreach (var subscriber in subscribersArray!)
        {
            var subscriberId = subscriber["id"];
            var magazineIds = subscriber["magazineIds"].Select(m => m.Value<int>()).ToList();

            bool allCategoriesContainMagazines = true;
            foreach (var categoryId in categoryIds)
            {
                var magazinesForCategory = await GetMagazinesForCategory(token, categoryId);
                if (!ContainsAny(magazinesForCategory, magazineIds))
                {
                    allCategoriesContainMagazines = false;
                    break;
                }
            }

            if (allCategoriesContainMagazines)
            {
                Console.WriteLine(subscriberId);
                subscriberIds.Add(subscriberId?.ToString());
            }
        }

        return subscriberIds;
    }

    private async Task<List<int>> GetMagazinesForCategory(string token, string categoryId)
    {
        var response = await _httpClient.GetAsync($"{_baseUrl}/api/magazines/{token}/{categoryId}");
        response.EnsureSuccessStatusCode();
        var magazinesResponse = await response.Content.ReadAsStringAsync();
        JObject jsonObject = JObject.Parse(magazinesResponse);
        var magazines = (JArray)jsonObject["data"];
        return magazines?.Select(m => m.Value<int>("id")).ToList();
    }

    private static bool ContainsAny<T>(IEnumerable<T> list, IEnumerable<T> items)
    {
        return items.Any(item => list.Contains(item));
    }
}