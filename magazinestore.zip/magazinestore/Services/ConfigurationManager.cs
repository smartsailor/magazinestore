using Microsoft.Extensions.Configuration;

namespace magazinestore.Services;

public class ConfigurationManager
{
    private readonly IConfiguration _configuration;

    public ConfigurationManager(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public string GetBaseUrl()
    {
        return _configuration.GetSection("AppSettings:BaseUrl").Value;
    }
}