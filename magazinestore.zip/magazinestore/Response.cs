namespace magazinestore.Models;

public class JsonResponse
{
    public List<string> Data { get; set; }
    public bool Success { get; set; }
    public string Token { get; set; }
}

public class JsonStringToken
{
    public bool Success { get; set; }
    public string Token { get; set; }
}
