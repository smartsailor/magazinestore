﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Net.Http.Headers;
using magazinestore.Models;
using System.Text;
using magazinestore.Services;

var config = new ConfigurationBuilder()
            .AddJsonFile(@"C:\Users\Sudhir\task\core\magazinestore\appsettings.json", optional: false, reloadOnChange: true)
            .Build();

var configManager = new magazinestore.Services.ConfigurationManager(config);
var baseUrl = configManager.GetBaseUrl();

using (var httpClient = new HttpClient())
{
    var tokenManager = new TokenManager(httpClient, baseUrl);
    var categoryManager = new CategoryManager(httpClient, baseUrl);
    var subscriberManager = new SubscriberManager(httpClient, baseUrl);
    var answerSubmitter = new AnswerSubmitter(httpClient, baseUrl);

    try
    {
        var token = await tokenManager.GetToken();
        //Console.WriteLine(token);
        var categoryIds = await categoryManager.GetCategoryIds(token);   
        var subscriberIds = await subscriberManager.GetSubscriberIdsWithMagazinesInAllCategories(token, categoryIds);
        
        await answerSubmitter.SubmitAnswer(token, subscriberIds);
        Console.ReadLine();
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }

    Console.ReadLine();
}